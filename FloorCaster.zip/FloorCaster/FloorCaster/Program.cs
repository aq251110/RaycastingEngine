﻿using var game = new FloorCaster.Game1();
game.Run();
