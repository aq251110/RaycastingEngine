﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace FloorCaster
{
    public class Camera
    {
        public Vector2 position = new Vector2(10, 10);
        public Vector2 Dir  = new Vector2(1, 1);
        public Vector2 Map => new Vector2( (int)position.X / 100,  (int)position.Y / 100 ); 
        public float Angle
        {
            get => MathF.Atan2(Dir.Y, Dir.X);
            set
            {
                Dir.X = MathF.Cos(value);
                Dir.Y = MathF.Sin(value);
            }
        }
        public float Height = 1;
        public float Fov = 0.8f;



    }
}
