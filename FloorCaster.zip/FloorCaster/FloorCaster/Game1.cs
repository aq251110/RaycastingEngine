﻿
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using SharpDX.Direct3D9;
using System;
using System.Reflection.Metadata;

namespace FloorCaster
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        Camera cam  = new Camera();
        Texture2D Floor;
        Color[] FloorData;
        Texture2D FloorCanvas;
        Color[] FloorBuffer;
        KeyboardState keyboardState;
        MouseState mouse;
        const int Screen_Width = 1920;
        const int Screen_Height = 985;
        const int Horizon = Screen_Height / 2;


        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            _graphics.IsFullScreen = false;
            _graphics.PreferredBackBufferWidth = 1920;
            _graphics.PreferredBackBufferHeight = 985;
            _graphics.ApplyChanges();
            IsMouseVisible = false;

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            Floor = Content.Load<Texture2D>("Images");
            FloorData = new Color[Floor.Width * Floor.Height];
            Floor.GetData(FloorData);
            FloorCanvas = new Texture2D(GraphicsDevice, 1920, 985);
            FloorBuffer = new Color[1920 * 985];

        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here
            keyboardState = Keyboard.GetState();
            mouse = Mouse.GetState();

            if (keyboardState.IsKeyDown(Keys.S))
            {
                cam.position.X -= cam.Dir.X * 0.2f;
                cam.position.Y -= cam.Dir.Y * 0.2f;
            }

            if (keyboardState.IsKeyDown(Keys.W))
            {
                cam.position.X += cam.Dir.X * 0.2f;
                cam.position.Y += cam.Dir.Y * 0.2f;
            }

            if (keyboardState.IsKeyDown(Keys.D))
            {
                cam.position.X -= cam.Dir.Y * 0.1f;
                cam.position.Y += cam.Dir.X * 0.1f;
            }

            if (keyboardState.IsKeyDown(Keys.A))
            {
                cam.position.X += cam.Dir.Y * 0.1f;
                cam.position.Y -= cam.Dir.X * 0.1f;
            }
            int centerX = _graphics.PreferredBackBufferWidth / 2;

            int DeltaX = mouse.X - centerX;

            cam.Angle += DeltaX * 0.002f;
            Mouse.SetPosition(centerX, _graphics.PreferredBackBufferHeight / 2);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
//            // Define core constants
//            Constant SCREEN_WIDTH = 1920
//            Constant SCREEN_HEIGHT = 985
//            Constant HORIZON = SCREEN_HEIGHT / 2
//            Constant FOV = 0.8  // Total field of view in radians (adjust to match your wall FOV)
//            Constant TEXTURE_SCALE = 0.05

//// 1. Loop through every horizontal row below the horizon
//For y = HORIZON + 1 To SCREEN_HEIGHT -1
//{
//                // Calculate the vertical distance from the horizon
//                Integer pixels_from_horizon = y - HORIZON

//    // Calculate straight-line distance to this floor row
//    // (Adjust the 30000 constant to stretch/shrink floor depth)
//    Float straight_distance = 30000.0 / pixels_from_horizon

//    // Compute row offset for a 1D pixel buffer array
//    Integer row_offset = y * SCREEN_WIDTH

//    // 2. Loop through every pixel column from left to right across this row
//    For x = 0 To SCREEN_WIDTH -1
//    {
//                    // Map column X to a normalized ratio between -1.0 (left) and +1.0 (right)
//                    Float screen_ratio = ((Float)x / SCREEN_WIDTH) * 2.0 - 1.0

//        // Find this column's specific angle offset relative to player center
//        Float relative_angle = screen_ratio * (FOV / 2.0)

//        // Combine with player's actual viewing angle to get absolute world direction
//        Float ray_angle = Guy.PlayerAngle + relative_angle

//        // 3. Apply fish-eye correction to get the real distance along this slanted ray
//        Float ray_distance = straight_distance / Math.Cos(relative_angle)

//        // 4. Project outwards from player position to find 3D floor coordinates
//        Float world_x = Guy.Position.X + (Math.Cos(ray_angle) * ray_distance)
//        Float world_y = Guy.Position.Y + (Math.Sin(ray_angle) * ray_distance)

//        // 5. Convert world space coordinates to texture coordinates (tiling)
//        Integer tex_x = FloorToInteger(world_x * TEXTURE_SCALE) Mod Brick.Width
//        Integer tex_y = FloorToInteger(world_y * TEXTURE_SCALE) Mod Brick.Height

//        // Handle negative coordinates safely so textures tile backwards
//        If tex_x < 0 Then tex_x = tex_x + Brick.Width
//        If tex_y< 0 Then tex_y = tex_y + Brick.Height

//        // Grab color from texture array and write directly to the screen pixel buffer
//        Color pixel_color = BrickData[(tex_y * Brick.Width) + tex_x]
//        FloorBuffer[row_offset + x] = pixel_color
//    }
//            }

//            // 6. Push buffer to GPU and render
//            FloorCanvas.SetData(FloorBuffer)
//SpriteBatch.Draw(FloorCanvas, Vector2.Zero, Color.White)






            
            //OH GOD LETS TRY AND CODE A FLOOR :0
            for (int y = Horizon + 1; y < Screen_Height - 1; y++)
            {
                int PixelsFromHorizon = y - Horizon; //this represents the current in game distance from the camera to the Scanline

                float StraightDistance = 3000f / PixelsFromHorizon;

                int RowOffset = y * Screen_Width;

                for (int x = 0; x <  Screen_Width; x++)
                {
                    float ScreenRatio = (float)x / Screen_Width * 2f - 1;
                    float RelativeAngle = ScreenRatio * (cam.Fov / 2f);
                    float RayAngle = cam.Angle + RelativeAngle;
                    float RayDistance = StraightDistance / MathF.Cos(RelativeAngle);

                    float WorldX = cam.position.X + (MathF.Cos(RayAngle) * RayDistance);
                    float WorldY = cam.position.Y + (MathF.Sin(RayAngle) * RayDistance);

                    int texX = (int)Math.Floor(WorldX * 7) % Floor.Width;
                    int texY = (int)Math.Floor(WorldY * 7) % Floor.Height;

                    if (texX < 0) { texX += Floor.Width; }
                    if (texY < 0) { texY += Floor.Height; }

                    Color pixel_color = FloorData[(texY * Floor.Width) + texX];
                    FloorBuffer[RowOffset + x] = pixel_color;
                    

                }


            }
            _spriteBatch.Begin();
            FloorCanvas.SetData(FloorBuffer);
            _spriteBatch.Draw(FloorCanvas, Vector2.Zero, Color.White);
            _spriteBatch.End();






            base.Draw(gameTime);
        }
    }
}
