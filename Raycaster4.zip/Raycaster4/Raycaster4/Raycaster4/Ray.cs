﻿using Microsoft.Xna.Framework;
using SharpDX.Direct3D9;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Raycaster4
{
    internal class Ray
    {

        //Ray Properties-------------------------
        public Vector2 Position = new Vector2();
        public int MapX => (int)(Position.X / 100);
        public int MapY => (int)(Position.Y / 100);
        public float RayAngle { get; set; }
        public float RayDistance = 0;
        public float DirX = 1;
        public float DirY = 1;
        //-------------------------------------------

        //Ray Methods--------------------------------
        public int Caster(Player p, Ray B, Map L, float input)
            {


                B.Position = p.Position;
                B.RayAngle = p.PlayerAngle + input * 0.8f; //FOV

                B.DirX = MathF.Cos(B.RayAngle);
                B.DirY = MathF.Sin(B.RayAngle);

            

                while (true)
                {


                   B.Position.X += B.DirX * 2f; //4 works well
                   B.Position.Y += B.DirY * 2f; //4 works well

                   if (L.Map1[B.MapY, B.MapX] == 1)
                    {
                        B.RayDistance = Vector2.Distance(p.Position, B.Position);
                        byte c = (byte)(B.RayDistance * 0.18);

                        L.WallColour = new Color(145-c , 145-c , 145-c);
                        //Debug.WriteLine(B.RayDistance);
                        break;
                    }


            }
            return (int)(3000f * 30 / B.RayDistance); //30 controlls the height of the wall


           }
        //-------------------------------------------

    }
}
