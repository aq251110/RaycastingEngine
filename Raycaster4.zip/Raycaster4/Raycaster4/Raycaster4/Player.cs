﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Raycaster4
{
    internal class Player
    {
        //Player Properties-------------------------
        public Vector2 Position = new Vector2(500, 500);
        public float DirX = 1;
        public float DirY = 1;
        public int MapX => (int)Position.X / 100;
        public int MapY => (int)Position.Y / 100;

        public float PlayerAngle
        {
            get => MathF.Atan2(DirY, DirX);
            set
            {
                DirY = MathF.Sin(value);
                DirX = MathF.Cos(value);
            }
        }
        public float PlaneY = 0.5f;
        public float PlaneX = 0.5f;
        //-------------------------------------------




    }
}
