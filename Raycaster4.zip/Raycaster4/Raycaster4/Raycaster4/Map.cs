﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raycaster4
{
    internal class Map
    {

        //Map Properties-------------------------
        public int[,] Map1 =
        {
            {1,1,1,1,1,1,1,1,1,1, 1},
            {1,0,0,0,0,0,0,0,0,1, 1},
            {1,0,0,0,0,0,3,0,0,1, 1},
            {1,0,0,0,0,0,0,0,0,1, 1},
            {1,0,0,0,1,0,0,0,0,1, 1},
            {1,0,0,0,0,0,0,0,0,1, 1},
            {1,0,0,0,0,0,0,0,0,1, 1},
            {1,0,0,0,0,0,0,0,0,1, 1},
            {1,0,0,0,0,0,0,0,0,1, 1},
            {1,1,1,1,1,1,1,1,1,1, 1}
        };
        public Color WallColour { set; get; }
        //-------------------------------------------


    }
}
