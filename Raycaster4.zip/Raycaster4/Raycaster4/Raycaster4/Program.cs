﻿using var game = new Raycaster4.Game1();
game.Run();
