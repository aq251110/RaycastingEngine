﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;


namespace Raycaster4
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        Texture2D pixel;
        KeyboardState keyboardState;
        MouseState mouse;
        Player Guy = new Player();
        Ray Beam = new Ray();
        Map Level = new Map();
        SpriteFont debug;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            _graphics.IsFullScreen = false;
            _graphics.PreferredBackBufferWidth = 1920;
            _graphics.PreferredBackBufferHeight = 985;
            _graphics.ApplyChanges();
            IsMouseVisible = false;

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            pixel = new Texture2D(GraphicsDevice, 1, 1);
            pixel.SetData(new[] { Color.White });
            debug = Content.Load<SpriteFont>("Fonty");
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            keyboardState = Keyboard.GetState();
            mouse = Mouse.GetState();

            if (keyboardState.IsKeyDown(Keys.S))
            {
                Guy.Position.X -= Guy.DirX * 3;
                Guy.Position.Y -= Guy.DirY * 3;
            }

            if (keyboardState.IsKeyDown(Keys.W))
            {
                Guy.Position.X += Guy.DirX * 3;
                Guy.Position.Y += Guy.DirY * 3;
            }

            if (keyboardState.IsKeyDown(Keys.D))
            {
                Guy.Position.X -= Guy.DirY * 3;
                Guy.Position.Y += Guy.DirX * 3;
            }

            if (keyboardState.IsKeyDown(Keys.A))
            {
                Guy.Position.X += Guy.DirY * 3;
                Guy.Position.Y -= Guy.DirX * 3;
            }
            int centerX = _graphics.PreferredBackBufferWidth / 2;

            int DeltaX = mouse.X - centerX;

            Guy.PlayerAngle += DeltaX * 0.002f;
            Mouse.SetPosition(centerX, _graphics.PreferredBackBufferHeight / 2);



            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            _spriteBatch.Begin();
            int StripsDrew = 0;

            for (float i = -1; i <= 1; i += 0.00104167f) //0.000961538
            {
                int WallHeight = Beam.Caster(Guy, Beam, Level, i);

                _spriteBatch.Draw(pixel, new Rectangle(StripsDrew, 540 - WallHeight / 2, 1, WallHeight), Level.WallColour); //540 -wh/2 is the y pos of the strip/wall
                StripsDrew++;

            }
            //_spriteBatch.DrawString(debug, Convert.ToString(Beam.RayDistance), new Vector2(0, 0), Color.Black);
            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
